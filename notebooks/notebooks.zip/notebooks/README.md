Se você quiser salvar algum arquivo permanentemente, ele deve estar nessa pasta.
